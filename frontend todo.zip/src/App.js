import { HomeRoute } from "./Routes/HomeRoute";

function App() {
  return <HomeRoute />;
}

export default App;
